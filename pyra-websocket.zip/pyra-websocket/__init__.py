# packages/pyra_websocket/__init__.py
import websocket
import json

def connect(url):
    ws = websocket.WebSocket()
    ws.connect(url)
    return ws

def send(ws, data):
    ws.send(json.dumps(data))

def receive(ws):
    return json.loads(ws.recv())