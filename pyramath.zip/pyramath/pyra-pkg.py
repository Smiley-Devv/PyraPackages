import os
import sys
import json
import urllib.request
import zipfile

# Path to store Pyra packages in your Pyra Runner folder
PACKAGE_DIR = r"C:\Program Files\PyraRunner\Pyra Runner\packages"
os.makedirs(PACKAGE_DIR, exist_ok=True)

def install(url):
    try:
        # Download the package zip
        file_name, _ = urllib.request.urlretrieve(url)
        with zipfile.ZipFile(file_name, "r") as zip_ref:
            zip_ref.extractall(PACKAGE_DIR)
        print("Package installed in:", PACKAGE_DIR)
    except PermissionError:
        print("Permission denied! Run this script as Administrator.")
    except Exception as e:
        print("Error installing package:", e)

def list_packages():
    for pkg in os.listdir(PACKAGE_DIR):
        path = os.path.join(PACKAGE_DIR, pkg, "pyra.json")
        if os.path.exists(path):
            data = json.load(open(path))
            print(f"{data['name']} - {data['version']} : {data['description']}")

def main():
    if len(sys.argv) < 2:
        print("Usage: pyra-pkg.py install <url> | list")
        return
    cmd = sys.argv[1].lower()
    if cmd == "install":
        if len(sys.argv) < 3:
            print("Please provide a URL to install")
            return
        install(sys.argv[2])
    elif cmd == "list":
        list_packages()
    else:
        print("Unknown command:", cmd)

if __name__ == "__main__":
    main()
